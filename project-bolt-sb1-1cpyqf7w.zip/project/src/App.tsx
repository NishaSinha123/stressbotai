import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Heart, Smile, Moon, Sun, Brain, Music, Coffee, Cog as Yoga } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  category?: 'breathing' | 'meditation' | 'exercise' | 'general';
}

const stressReliefResponses = {
  breathing: [
    "Let's try box breathing: Inhale for 4 counts, hold for 4, exhale for 4, hold for 4. Repeat 4 times.",
    "Practice the 4-7-8 breathing technique: Inhale for 4, hold for 7, exhale for 8. This helps activate your parasympathetic nervous system.",
    "Try alternate nostril breathing: Close your right nostril, inhale left, switch, exhale right. This balances your energy.",
  ],
  meditation: [
    "Close your eyes and imagine a peaceful place. What do you see, hear, and feel there?",
    "Let's do a body scan meditation. Start from your toes and slowly move attention up to your head.",
    "Focus on a calming word or phrase. Repeat it silently with each breath.",
  ],
  exercise: [
    "Stand up and do some gentle shoulder rolls - forward 5 times, then backward 5 times.",
    "Try this desk stretch: Interlace your fingers, stretch arms overhead, lean side to side.",
    "Walk in place for 1 minute, focusing on each step. Feel the movement in your body.",
  ],
  general: [
    "Remember: This moment of stress is temporary. You've handled difficult situations before.",
    "Take a moment to list 3 things you're grateful for right now.",
    "Consider writing down your thoughts. Sometimes getting them on paper helps clear your mind.",
    "Hydrate yourself. Taking a water break can help reset your stress response.",
  ]
};

const moodEmojis = ['😊', '😌', '😔', '😤', '😰', '😩'];

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Welcome message
    setTimeout(() => {
      const welcomeMessage: Message = {
        id: Date.now().toString(),
        text: "Hello! I'm your stress management assistant. How are you feeling today? You can select a mood below or type your feelings. Remember, it's okay to not be okay. I'm here to help you manage stress and anxiety.",
        sender: 'bot',
        timestamp: new Date(),
        category: 'general',
      };
      setMessages([welcomeMessage]);
    }, 1000);
  }, []);

  const getStressReliefResponse = (userInput: string): Message => {
    let category: 'breathing' | 'meditation' | 'exercise' | 'general' = 'general';
    const input = userInput.toLowerCase();
    
    if (input.includes('breath') || input.includes('air') || input.includes('suffocat')) {
      category = 'breathing';
    } else if (input.includes('meditat') || input.includes('calm') || input.includes('peace')) {
      category = 'meditation';
    } else if (input.includes('move') || input.includes('exercise') || input.includes('stretch')) {
      category = 'exercise';
    }

    const responses = stressReliefResponses[category];
    const randomIndex = Math.floor(Math.random() * responses.length);

    return {
      id: Date.now().toString(),
      text: responses[randomIndex],
      sender: 'bot',
      timestamp: new Date(),
      category,
    };
  };

  const getCategoryIcon = (category?: string) => {
    switch (category) {
      case 'breathing':
        return <Wind className="w-4 h-4" />;
      case 'meditation':
        return <Brain className="w-4 h-4" />;
      case 'exercise':
        return <Yoga className="w-4 h-4" />;
      default:
        return <Heart className="w-4 h-4" />;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() && !selectedMood) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: selectedMood ? `I'm feeling ${selectedMood}` : input,
      sender: 'user',
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setSelectedMood(null);
    setIsTyping(true);

    // Simulate bot response with stress management focus
    setTimeout(() => {
      const botMessage = getStressReliefResponse(userMessage.text);
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-indigo-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-100 to-purple-100'
    }`}>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <header className="text-center mb-8 relative">
          <button
            onClick={toggleTheme}
            className="absolute right-4 top-0 p-2 rounded-full hover:bg-opacity-20 hover:bg-white transition-colors"
          >
            {isDarkMode ? <Sun className="text-white" /> : <Moon className="text-gray-800" />}
          </button>
          <div className="flex items-center justify-center mb-2">
            <Heart className={`w-8 h-8 mr-2 ${isDarkMode ? 'text-pink-400' : 'text-pink-500'}`} />
            <h1 className={`text-4xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
              Stress Relief Assistant
            </h1>
          </div>
          <p className={`${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            Your companion for peace and calm
          </p>
          <div className="flex justify-center gap-4 mt-4">
            <div className={`inline-flex gap-2 p-2 rounded-lg ${
              isDarkMode ? 'bg-gray-800' : 'bg-white'
            }`}>
              <Brain className={isDarkMode ? 'text-purple-400' : 'text-purple-600'} />
              <Music className={isDarkMode ? 'text-pink-400' : 'text-pink-600'} />
              <Coffee className={isDarkMode ? 'text-yellow-400' : 'text-yellow-600'} />
              <Yoga className={isDarkMode ? 'text-green-400' : 'text-green-600'} />
            </div>
          </div>
        </header>

        <div className={`rounded-lg shadow-xl overflow-hidden ${
          isDarkMode ? 'bg-gray-800' : 'bg-white'
        }`}>
          <div className="h-[600px] overflow-y-auto p-6">
            {messages.length === 0 && (
              <div className={`text-center mt-32 ${
                isDarkMode ? 'text-gray-400' : 'text-gray-500'
              }`}>
                <Smile size={48} className="mx-auto mb-4" />
                <p>Take a deep breath. I'm here to help you manage stress.</p>
              </div>
            )}
            
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex items-start space-x-2 mb-4 ${
                  message.sender === 'user' ? 'flex-row-reverse' : ''
                }`}
              >
                <div
                  className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                    message.sender === 'user' 
                      ? 'bg-purple-500' 
                      : 'bg-pink-500'
                  }`}
                >
                  {message.sender === 'user' ? (
                    <User size={20} className="text-white" />
                  ) : (
                    getCategoryIcon(message.category)
                  )}
                </div>
                <div
                  className={`px-4 py-2 rounded-lg max-w-[80%] ${
                    message.sender === 'user'
                      ? 'bg-purple-600 ml-auto'
                      : isDarkMode ? 'bg-pink-900' : 'bg-pink-100'
                  }`}
                >
                  <p className={`text-sm ${
                    message.sender === 'user' || isDarkMode 
                      ? 'text-white' 
                      : 'text-gray-800'
                  }`}>{message.text}</p>
                  <span className="text-xs text-gray-400 mt-1 block">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center space-x-2 text-gray-400">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm">Thinking of ways to help...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className={`border-t ${
            isDarkMode ? 'border-gray-700' : 'border-gray-200'
          }`}>
            <div className="p-2 flex justify-center gap-2">
              {moodEmojis.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => setSelectedMood(emoji)}
                  className={`text-2xl p-2 rounded-full transition-transform hover:scale-110 ${
                    selectedMood === emoji ? 'bg-purple-100 scale-110' : ''
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
            <form
              onSubmit={handleSubmit}
              className={`p-4 ${
                isDarkMode 
                  ? 'bg-gray-800' 
                  : 'bg-white'
              }`}
            >
              <div className="flex space-x-4">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Share how you're feeling..."
                  className={`flex-1 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                    isDarkMode 
                      ? 'bg-gray-700 text-white' 
                      : 'bg-gray-100 text-gray-800'
                  }`}
                />
                <button
                  type="submit"
                  disabled={!input.trim() && !selectedMood}
                  className="bg-purple-500 hover:bg-purple-600 disabled:bg-gray-500 disabled:cursor-not-allowed text-white rounded-lg px-6 py-2 flex items-center space-x-2 transition-colors"
                >
                  <span>Send</span>
                  <Send size={18} />
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;